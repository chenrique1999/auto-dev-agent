import { writeFileSync } from 'fs';
const now = new Date().toISOString();
const data = { status: 'ok', tests: 'passed', lastUpdate: now };
writeFileSync('.atlas/status.json', JSON.stringify(data, null, 2));
console.log('[atlas] status atualizado');
