// server.mjs — versão estável/limpa
import express from "express";
import process from "process";
import os from "os";
import { spawn } from "child_process";
import crypto from "crypto";
import "dotenv/config";

// ====== CONFIG ======
const PORT = Number(process.env.AGENT_PORT || process.env.PORT || 7777);
const FULL_TOKEN = (process.env.AGENT_TOKEN || "").trim(); // [patch]
const REPO_DIR = process.env.REPO_DIR || process.cwd();
const TOKEN = (process.env.AGENT_TOKEN || "").trim();

// ====== APP ======
const app = express();
app.use(express.json({ limit: "1mb" }));

// ====== UTILS ======
class LogList {
  constructor() { this._items = []; }
  push(s) { this._items.push(String(s)); }
  length() { return this._items.length; }
  sliceFrom(cursor) {
    const c = Number(cursor || 0);
    const items = this._items.slice(c);
    const nextCursor = this._items.length;
    return { items, nextCursor };
  }
}

const tasks = new Map(); // id -> {id, status, logs:LogList, pid, startedAt, endedAt, exitCode}

function nowISO() { return new Date().toISOString(); }

function sanitizeText(s) {
  // remove apenas controles não-imprimíveis (mantém \r\n)
  return String(s).replace(/[\u0000-\u0009\u000B\u000C\u000E-\u001F\u007F]/g, "");
}

function okJson(res, data) {
  res.set("Content-Type", "application/json; charset=utf-8");
  res.json(data);
}

// ====== AUTH (token) ======
function auth(req, res, next) {
  const want = TOKEN;
  if (!want) return res.status(500).json({ error: "missing-agent-token" });

  const a = req.headers.authorization || "";
  const x = req.headers["x-agent-token"];
  let got = "";
  if (a && typeof a === "string" && a.toLowerCase().startsWith("bearer "))
    got = a.slice(7).trim();
  else if (typeof x === "string") got = String(x).trim();

  if (got !== want) {
    return res.status(401).json({
      error: "unauthorized",
      gotLen: got.length, wantLen: want.length,
      gotPrefix: got.slice(0, 12), wantPrefix: want.slice(0, 12)
    });
  }
  next();
}

// ====== DEBUG (sem auth, pra diagnosticar token/headers) ======
app.get("/__debug-token", (req, res) => {
  const t = TOKEN;
  okJson(res, { len: t.length, prefix: t.slice(0, 12) });
});
app.get("/__echo-auth", (req, res) => {
  const want = TOKEN;
  okJson(res, {
    wantLen: want.length,
    wantPrefix: want.slice(0, 12),
    auth: req.headers.authorization || null,
    xAgentToken: req.headers["x-agent-token"] || null
  });
});

// ====== HEALTH ======
app.get("/health", (req, res) => {
  okJson(res, { ok: true, ts: nowISO(), pid: process.pid, cwd: REPO_DIR });
});

// ====== RUN (assíncrono) ======
app.post("/run-async", auth, (req, res) => {
  const task = (req?.body?.task ?? "").toString();
  if (!task.trim()) return res.status(400).json({ error: "missing task" });

  const id = crypto.randomUUID();
  const logs = new LogList();

  const isWin = process.platform === "win32";
  const cmd = isWin ? "powershell.exe" : "bash";
  const args = isWin ? ["-NoLogo", "-NoProfile", "-Command", task] : ["-lc", task];

  const child = spawn(cmd, args, {
    cwd: REPO_DIR,
    env: { ...process.env },
    shell: false
  });

  const rec = {
    id,
    status: "running",
    logs,
    pid: child.pid,
    startedAt: nowISO(),
    endedAt: null,
    exitCode: null
  };
  tasks.set(id, rec);

  const pipe = (src, tag) => {
    src.on("data", (buf) => {
      let s = "";
      try { s = buf.toString("utf8"); } catch { s = String(buf); }
      logs.push(s);
    });
  };
  pipe(child.stdout, "out");
  pipe(child.stderr, "err");

  child.on("error", (err) => {
    logs.push(`\n[child:error] ${String(err?.message || err)}\n`);
  });

  child.on("exit", (code, signal) => {
    rec.exitCode = code ?? null;
    rec.status = code === 0 ? "done" : "error";
    rec.endedAt = nowISO();
    if (signal) logs.push(`\n[child:signal] ${signal}\n`);
  });

  okJson(res, { taskId: id, status: rec.status, pid: rec.pid, startedAt: rec.startedAt });
});

// ====== STATUS ======
app.get("/tasks/:id/status", auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).json({ error: "not found" });
  okJson(res, {
    id: t.id, status: t.status, pid: t.pid,
    startedAt: t.startedAt, endedAt: t.endedAt, exitCode: t.exitCode
  });
});
app.get("/tasks/:id/status-json", auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).json({ error: "not found" });
  okJson(res, {
    id: t.id, status: t.status, pid: t.pid,
    startedAt: t.startedAt, endedAt: t.endedAt, exitCode: t.exitCode
  });
});

// --- BEGIN: sanitized logs endpoints ---
function __sanitize(s) {
  return String(s).replace(/[\u0000-\u0009\u000B\u000C\u000E-\u001F\u007F]/g, '');
}

// JSON sanitizado (+ long-poll) com opção encoding=b64
app.get('/tasks/:id/logs-json', auth, async (req,res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).json({ error: 'not found' });

  const cursor  = Number(req.query.cursor || 0);
  const timeout = Math.min(Number(req.query.timeout || 25000), 60000);
  const start   = Date.now();
  const enc     = (req.query.encoding === 'b64') ? 'b64' : 'text';

  const send = () => {
    const { items, nextCursor } = t.logs.sliceFrom(cursor);
    let payloadItems;
    if (enc === 'b64') {
      res.set('X-Log-Encoding', 'b64');
      payloadItems = items.map(s => Buffer.from(String(s), 'utf8').toString('base64'));
    } else {
      res.set('X-Log-Encoding', 'text');
      payloadItems = items.map(__sanitize);
    }
    res.json({ items: payloadItems, nextCursor, done: t.status !== 'running', encoding: enc });
  };

  if (t.logs.length() > cursor) return send();
  while (Date.now() - start < timeout && t.status === 'running' && t.logs.length() <= cursor) {
    await new Promise(r => setTimeout(r, 400));
  }
  return send();
});

// Texto puro (sem JSON) com espera simples
app.get('/tasks/:id/logs-plain', auth, async (req,res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).send('not found');

  const cursor  = Number(req.query.cursor || 0);
  const timeout = Math.min(Number(req.query.timeout || 25000), 60000);
  const start   = Date.now();

  const send = () => {
    const { items, nextCursor } = t.logs.sliceFrom(cursor);
    res.set('Content-Type', 'text/plain; charset=utf-8');
    res.send(items.map(__sanitize).join(''));
  };

  if (t.logs.length() > cursor) return send();
  while (Date.now() - start < timeout && t.status === 'running' && t.logs.length() <= cursor) {
    await new Promise(r => setTimeout(r, 400));
  }
  return send();
});
// --- END: sanitized logs endpoints ---

// ====== START ======
app.listen(PORT, "0.0.0.0", () => {
// --- BEGIN: SSE logs endpoint ---
app.get("/tasks/:id/sse", auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).end();
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  res.flushHeaders && res.flushHeaders();
  let cursor = Number(req.query.cursor || 0);
  const keepAlive = setInterval(() => { try { res.write(":\n\n") } catch {} }, 15000);
  const send = () => {
    const { items, nextCursor } = t.logs.sliceFrom(cursor);
    for (const line of items) {
      const b64 = Buffer.from(String(line), "utf8").toString("base64");
      res.write("event: log\n");
      res.write("data: " + JSON.stringify({ b64 }) + "\n\n");
    }
    cursor = nextCursor;
    if (t.status !== "running") {
      res.write("event: done\n");
      res.write("data: " + JSON.stringify({ status: t.status }) + "\n\n");
      clearInterval(keepAlive);
      try { res.end() } catch {}
      return true;
    }
    return false;
  };
  // disparo inicial
  try { send() } catch {}
  const poll = setInterval(() => {
    if (res.writableEnded) { clearInterval(poll); clearInterval(keepAlive); return }
    try {
      const _ = (t && t.logs) ? t.logs.length() : 0;
      if (_ > cursor || t.status !== "running") { if (send()) { clearInterval(poll); } }
    } catch {}
  }, 500);
  req.on("close", () => { clearInterval(poll); clearInterval(keepAlive); });
});
// --- END: SSE logs endpoint ---
// --- BEGIN: SSE logs endpoint ---
app.get("/tasks/:id/sse", auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).end();
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  res.flushHeaders && res.flushHeaders();
  let cursor = Number(req.query.cursor || 0);
  const keepAlive = setInterval(() => { try { res.write(":\n\n") } catch {} }, 15000);
  const send = () => {
    const { items, nextCursor } = t.logs.sliceFrom(cursor);
    for (const line of items) {
      const b64 = Buffer.from(String(line), "utf8").toString("base64");
      res.write("event: log\n");
      res.write("data: " + JSON.stringify({ b64 }) + "\n\n");
    }
    cursor = nextCursor;
    if (t.status !== "running") {
      res.write("event: done\n");
      res.write("data: " + JSON.stringify({ status: t.status }) + "\n\n");
      clearInterval(keepAlive);
      try { res.end() } catch {}
      return true;
    }
    return false;
  };
  // disparo inicial
  try { send() } catch {}
  const poll = setInterval(() => {
    if (res.writableEnded) { clearInterval(poll); clearInterval(keepAlive); return }
    try {
      const _ = (t && t.logs) ? t.logs.length() : 0;
      if (_ > cursor || t.status !== "running") { if (send()) { clearInterval(poll); } }
    } catch {}
  }, 500);
  req.on("close", () => { clearInterval(poll); clearInterval(keepAlive); });
});
// --- END: SSE logs endpoint ---
// --- BEGIN: SSE logs endpoint ---
app.get("/tasks/:id/sse", auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).end();
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  res.flushHeaders && res.flushHeaders();
  let cursor = Number(req.query.cursor || 0);
  const keepAlive = setInterval(() => { try { res.write(":\n\n") } catch {} }, 15000);
  const send = () => {
    const { items, nextCursor } = t.logs.sliceFrom(cursor);
    for (const line of items) {
      const b64 = Buffer.from(String(line), "utf8").toString("base64");
      res.write("event: log\n");
      res.write("data: " + JSON.stringify({ b64 }) + "\n\n");
    }
    cursor = nextCursor;
    if (t.status !== "running") {
      res.write("event: done\n");
      res.write("data: " + JSON.stringify({ status: t.status }) + "\n\n");
      clearInterval(keepAlive);
      try { res.end() } catch {}
      return true;
    }
    return false;
  };
  // disparo inicial
  try { send() } catch {}
  const poll = setInterval(() => {
    if (res.writableEnded) { clearInterval(poll); clearInterval(keepAlive); return }
    try {
      const _ = (t && t.logs) ? t.logs.length() : 0;
      if (_ > cursor || t.status !== "running") { if (send()) { clearInterval(poll); } }
    } catch {}
  }, 500);
  req.on("close", () => { clearInterval(poll); clearInterval(keepAlive); });
});
// --- END: SSE logs endpoint ---
// --- BEGIN: SSE logs endpoint ---
app.get("/tasks/:id/sse", auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).end();
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no"
  });
  res.flushHeaders && res.flushHeaders();
  let cursor = Number(req.query.cursor || 0);
  const keepAlive = setInterval(() => { try { res.write(":\n\n") } catch {} }, 15000);
  const send = () => {
    const { items, nextCursor } = t.logs.sliceFrom(cursor);
    for (const line of items) {
      const b64 = Buffer.from(String(line), "utf8").toString("base64");
      res.write("event: log\n");
      res.write("data: " + JSON.stringify({ b64 }) + "\n\n");
    }
    cursor = nextCursor;
    if (t.status !== "running") {
      res.write("event: done\n");
      res.write("data: " + JSON.stringify({ status: t.status }) + "\n\n");
      clearInterval(keepAlive);
      try { res.end() } catch {}
      return true;
    }
    return false;
  };
  // disparo inicial
  try { send() } catch {}
  const poll = setInterval(() => {
    if (res.writableEnded) { clearInterval(poll); clearInterval(keepAlive); return }
    try {
      const _ = (t && t.logs) ? t.logs.length() : 0;
      if (_ > cursor || t.status !== "running") { if (send()) { clearInterval(poll); } }
    } catch {}
  }, 500);
  req.on("close", () => { clearInterval(poll); clearInterval(keepAlive); });
});
// --- END: SSE logs endpoint ---
  console.log(`[srv] listening http://localhost:${PORT}  pid=${process.pid}`);
  console.log(`[srv] cwd=${REPO_DIR}`);
});

// --- BEGIN: token cfg (fallback a partir de AGENT_TOKEN) ---
const FULL = (process.env.AGENT_TOKEN || '').trim();
let TOKEN_PREFIX = (process.env.AGENT_TOKEN_PREFIX || '').trim();
let TOKEN_LEN = Number(process.env.AGENT_TOKEN_LEN || 0);

if (FULL && (!TOKEN_PREFIX || !TOKEN_LEN)) {
  // Deriva prefix/len do token completo se prefix/len não vierem no .env
  TOKEN_PREFIX = FULL.slice(0, Math.min(12, FULL.length));
  TOKEN_LEN = FULL.length;
}

// Se já existir um /__debug-token no arquivo, você pode manter o existente
// ou comentar e usar este aqui:
if (typeof app?.get === 'function') {
  app.get('/__debug-token', (_req, res) => {
    res.json({ len: TOKEN_LEN, prefix: TOKEN_PREFIX });
  });
}
// --- END: token cfg ---
// --- BEGIN: sanitized status endpoint ---
function __sanitizeAny(x) {
  if (typeof x === 'string') return __sanitize(x);
  if (Array.isArray(x)) return x.map(__sanitizeAny);
  if (x && typeof x === 'object') {
    const out = {};
    for (const k of Object.keys(x)) out[k] = __sanitizeAny(x[k]);
    return out;
  }
  return x;
}

app.get('/tasks/:id/status-json', auth, (req, res) => {
  const t = tasks.get(req.params.id);
  if (!t) return res.status(404).json({ error: 'not found' });

  // snapshot estritamente JSON
  const snap = {
    id: t.id,
    status: t.status,
    createdAt: t.createdAt,
    updatedAt: t.updatedAt,
    result: __sanitizeAny(t.result ?? null),
  };
  res.json(snap);
});
// --- END: sanitized status endpoint ---
