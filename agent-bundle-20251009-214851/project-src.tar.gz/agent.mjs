import 'dotenv/config';
import OpenAI from 'openai';
import { execa } from 'execa';
import { promises as fs } from 'fs';
import path from 'node:path';
import simpleGit from 'simple-git';
import { fetch } from 'undici';

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const REPO_DIR   = process.env.REPO_DIR || process.cwd();

// modelos / limites
const MODEL_FAST  = process.env.MODEL_FAST  || 'gpt-5-mini';
const MODEL_SMART = process.env.MODEL_SMART || 'gpt-5';
const ERR_LIMIT   = parseInt(process.env.SWITCH_AFTER_ERRORS || '2', 10);
const BYTE_LIMIT  = parseInt(process.env.LARGE_EDIT_BYTES    || '60000', 10);
const MAX_STEPS   = parseInt(process.env.AGENT_MAX_STEPS     || '25', 10);

// Senior / auto-reparo
const SENIOR     = process.env.SENIOR_MODE === '1';
const SELF_HEAL  = process.env.SELF_HEAL !== '0';
const REPAIR_HINT = process.env.REPAIR_HINT || '';

const ERR_LIMIT_EFF  = SENIOR ? Math.min(ERR_LIMIT, 1)   : ERR_LIMIT;
const BYTE_LIMIT_EFF = SENIOR ? Math.min(BYTE_LIMIT, 3e4): BYTE_LIMIT;

// dicas dinâmicas (ajuda o auto-reparo)
const HINTS = [
  { rx: /ERESOLVE|dependency conflict|peer dep/i, hint: 'Conflito de dependência? Tente: npm i --legacy-peer-deps' },
  { rx: /command not found: ts-node|Cannot find module 'ts-node'/i, hint: 'Instale TS: npm i -D typescript ts-node @types/node' },
  { rx: /EADDRINUSE|address already in use|port \d+ is already allocated/i, hint: 'Porta ocupada: kill $(lsof -t -i:3000) || true ou use outra porta' },
  { rx: /nodemon: not found|cannot find module 'nodemon'/i, hint: 'Instale nodemon (dev) ou use node diretamente' },
  { rx: /Missing script:.*start/i, hint: 'Adicione "start": "node server.js" no package.json' },
  { rx: /Cannot find module 'express'|ERR_MODULE_NOT_FOUND.*express/i, hint: 'Instale express: npm i express' },
];

function isDangerous(cmd='') {
  const bad = [ /\brm\s+-rf\s+\/\b/i, /\bsudo\b/i, /\bshutdown\b/i, /\breboot\b/i, /\bmkfs\b/i ];
  return bad.some(r => r.test(cmd));
}

// ---------- helpers ----------
async function run(cmd, cwd = REPO_DIR) {
  // remove caracteres de controle + sequências ANSI
  const clean = s => String(s)
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\x80-\x9F]/g, '')
    .replace(/\x1B\[[0-9;]*[A-Za-z]/g, '');
  try {
    const { stdout, stderr, exitCode } = await execa(cmd, {
      shell: true,
      cwd,
      // força sem cor nos processos chamados
      env: { ...process.env, FORCE_COLOR: '0', NO_COLOR: '1', TERM: 'dumb' }
    });
    return { ok: exitCode === 0, stdout: clean(stdout), stderr: clean(stderr), exitCode };
  } catch (e) {
    return {
      ok: false,
      stdout: clean(e.stdout || ''),
      stderr: clean(e.stderr || String(e)),
      exitCode: e.exitCode ?? -1
    };
  }
}
async function exists(p) { try { await fs.access(p); return true; } catch { return false; } }
async function writeFileSafe(relPath, content, mode='replace') {
  const abs = path.join(REPO_DIR, relPath);
  await fs.mkdir(path.dirname(abs), { recursive: true });
  if (mode === 'append' && (await exists(abs))) {
    const prev = await fs.readFile(abs, 'utf8');
    await fs.writeFile(abs, prev + content, 'utf8');
  } else {
    await fs.writeFile(abs, content, 'utf8');
  }
  return `wrote ${relPath} (${content.length} chars, mode=${mode})`;
}
async function readFileSafe(relPath, maxBytes=200000) {
  const abs = path.join(REPO_DIR, relPath);
  const buf = await fs.readFile(abs);
  return buf.slice(0, maxBytes).toString('utf8');
}
async function gitCommitPush(message='agent: update') {
  const git = simpleGit(REPO_DIR);
  await git.add('.');
  const status = await git.status();
  if (status.staged.length === 0) return 'no changes to commit';
  await git.commit(message);
  try { await git.push(); return `pushed: ${message}`; }
  catch (e) { return `commit ok, push failed: ${e}`; }
}
async function deployRender() {
  const url = process.env.RENDER_DEPLOY_HOOK;
  if (!url) return 'RENDER_DEPLOY_HOOK not set';
  const r = await fetch(url, { method: 'POST' });
  return `render hook status: ${r.status}`;
}
async function deployNetlify(dir=REPO_DIR) {
  const hasToken = !!process.env.NETLIFY_AUTH_TOKEN && !!process.env.NETLIFY_SITE_ID;
  const out = await run(
    hasToken
      ? `netlify deploy --dir="${dir}" --site ${process.env.NETLIFY_SITE_ID} --prod --auth ${process.env.NETLIFY_AUTH_TOKEN}`
      : `netlify deploy --dir="${dir}" --prod`
  );
  return out.stdout || out.stderr;
}

// ---------- tools ----------
const tools = [
  { type:'function', function:{ name:'run_shell', description:'Executa comando de shell', parameters:{ type:'object', properties:{ cmd:{type:'string'}, cwd:{type:'string'} }, required:['cmd'] } } },
  { type:'function', function:{ name:'write_file', description:'Escreve arquivo relativo ao REPO_DIR', parameters:{ type:'object', properties:{ path:{type:'string'}, content:{type:'string'}, mode:{type:'string',enum:['replace','append'],default:'replace'} }, required:['path','content'] } } },
  { type:'function', function:{ name:'read_file', description:'Lê arquivo', parameters:{ type:'object', properties:{ path:{type:'string'}, maxBytes:{type:'integer',default:200000} }, required:['path'] } } },
  { type:'function', function:{ name:'git_commit_push', description:'Commit + push', parameters:{ type:'object', properties:{ message:{type:'string'} } } } },
  { type:'function', function:{ name:'deploy_render', description:'Deploy no Render via hook', parameters:{ type:'object', properties:{} } } },
  { type:'function', function:{ name:'deploy_netlify', description:'Deploy no Netlify via CLI', parameters:{ type:'object', properties:{ dir:{type:'string'} } } } },
];

// ---------- heurística ----------
function toolOutputIndicatesFailure(output) {
  try {
    const o = JSON.parse(output);
    if (o && typeof o === 'object') {
      if (o.ok === false) return true;
      if (typeof o.exitCode === 'number' && o.exitCode !== 0) return true;
      if (o.stderr && String(o.stderr).trim()) return true;
    }
  } catch {}
  if (/tool error/i.test(output)) return true;
  if (/(^|\n)(ERR|Error|Traceback|failed)(:|\b)/i.test(output) && !/0 failed/i.test(output)) return true;
  return false;
}
function extractDynamicHints(outputs) {
  const joined = outputs.join('\n').slice(-6000);
  const hints = [];
  for (const { rx, hint } of HINTS) if (rx.test(joined)) hints.push(hint);
  if (REPAIR_HINT) hints.push(REPAIR_HINT);
  return Array.from(new Set(hints)).join(' | ');
}

// ---------- loop principal ----------
export async function runTask(userText, maxSteps=MAX_STEPS, onLog=(line)=>console.log(line)) {
  let failures = 0;
  let editedBytes = 0;
  let currentModel = MODEL_FAST;

  const messages = [
    { role:'system', content:
`Você é um ENGENHEIRO SÊNIOR operando SOMENTE em ${REPO_DIR}.
Regras:
1) Planeje rápido (arquivos/rotas/scripts) e defina CRITÉRIOS DE PRONTO (ex.: "npm test passa", "curl /health 200").
2) Implemente em passos curtos. Explique cada ação em 1–2 linhas.
3) Se falhar, DIAGNOSTIQUE → CORRIJA → REPITA automaticamente.
4) Valide: lint/test/build e smoke. Só finalize quando passar.
Evite comandos perigosos/sudo. Não saia de ${REPO_DIR}.` },
    { role:'user', content: userText }
  ];

  onLog(`[AI] using model: ${currentModel}`);

  for (let step=0; step<maxSteps; step++) {
    let resp;
    try {
      resp = await client.chat.completions.create({ model: currentModel, messages, tools, tool_choice:'auto' });
    } catch (e) {
      const code = e?.code || e?.error?.code || e?.status || 'unknown';
      onLog(`[AI][openai-error] ${code}`);
      if (currentModel !== MODEL_SMART) {
        currentModel = MODEL_SMART;
        onLog(`[AI] [switch] escalando para ${MODEL_SMART} (motivo: openai error: ${code})`);
        messages.push({ role:'system', content:'Erro do provedor. Replaneje resumidamente e continue.' });
        continue;
      }
      throw e;
    }

    const msg = resp.choices[0].message;
    if (msg.content) onLog(`[AI] ${msg.content}`);
    messages.push(msg); // importante: primeiro adiciona a msg com as tool_calls

    const calls = msg.tool_calls ?? [];
    if (!calls.length) return resp;

    let roundFailed = false;
    const roundOutputs = [];

    for (const call of calls) {
      const fn = call.function?.name;
      const argStr = call.function?.arguments || '{}';
      const tool_call_id = call.id;

      let args = {}; try { args = JSON.parse(argStr); } catch {}
      if (fn === 'write_file' && args.content) {
        editedBytes += Buffer.byteLength(args.content, 'utf8');
      }

      let output = '';
      try {
        if      (fn === 'run_shell')       output = JSON.stringify(await run(args.cmd, args.cwd || REPO_DIR));
        else if (fn === 'write_file')      output = await writeFileSafe(args.path, args.content, args.mode || 'replace');
        else if (fn === 'read_file')       output = await readFileSafe(args.path, args.maxBytes || 200000);
        else if (fn === 'git_commit_push') output = await gitCommitPush(args.message || 'agent update');
        else if (fn === 'deploy_render')   output = await deployRender();
        else if (fn === 'deploy_netlify')  output = await deployNetlify(args.dir);
        else                               output = `unknown tool: ${fn}`;
      } catch (e) {
        output = `tool error: ${e?.message || String(e)}`;
      }

      roundOutputs.push(output);
      if (toolOutputIndicatesFailure(output)) roundFailed = true;

      // IMPORTANTÍSSIMO: UMA mensagem role:"tool" POR tool_call, com o MESMO ID
      messages.push({ role:'tool', tool_call_id, content: String(output) });
    }

    if (roundFailed && SELF_HEAL) {
      failures++;
      const dynamic = extractDynamicHints(roundOutputs);
      let healMsg = `Auto-reparo: a rodada falhou. Use os logs e aplique correções (instalar deps, ajustar scripts/código) e REPITA até passar nos critérios.`;
      if (dynamic) healMsg += ` Sugestões: ${dynamic}`;
      messages.push({ role:'system', content: healMsg });
    }

    if ((failures >= ERR_LIMIT_EFF || editedBytes >= BYTE_LIMIT_EFF) && currentModel !== MODEL_SMART) {
      currentModel = MODEL_SMART;
      onLog(`[AI] [switch] escalando para ${MODEL_SMART} (motivo: ${failures >= ERR_LIMIT_EFF ? 'falhas' : 'edição grande'})`);
      messages.push({ role:'system', content:'Agora opere com mais cuidado e valide os critérios de pronto.' });
    }
  }

  throw new Error('maxSteps reached');
}

// ---------- CLI ----------
if (process.argv[1] === new URL(import.meta.url).pathname) {
  const task = process.argv.slice(2).join(' ') || 'Rode npm test. Se falhar, corrija e rode novamente até passar.';
  console.log('> Task:', task);
  await runTask(task);
}
